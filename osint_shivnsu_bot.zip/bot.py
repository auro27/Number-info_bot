#!/usr/bin/env python3

import os
import sqlite3
import requests
import json
import logging
import traceback
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes
)
from telegram.error import TelegramError

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8953664897:AAEe71VGoNvImHbk53ibbP8BQUX2qLO8uqc")
OWNER_IDS = {6236556853}
_owner_env = os.environ.get("OWNER_ID", "")
if _owner_env:
    for x in _owner_env.split(","):
        if x.strip().isdigit():
            OWNER_IDS.add(int(x.strip()))

DEFAULT_CREDITS = 5
BASE = "https://api.sarkariallupdates.com/api"
KEY = "30day"
DB_PATH = "credits.db"

logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            credits INTEGER DEFAULT 5,
            username TEXT,
            full_name TEXT
        )
    """)
    conn.commit()
    conn.close()


def get_user(user_id, username="", full_name=""):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
    row = c.fetchone()
    if row is None:
        c.execute("INSERT INTO users (user_id, credits, username, full_name) VALUES (?,?,?,?)",
                  (user_id, DEFAULT_CREDITS, username or "", full_name or ""))
        conn.commit()
        credits = DEFAULT_CREDITS
    else:
        credits = row[0]
        if username or full_name:
            c.execute("UPDATE users SET username=?, full_name=? WHERE user_id=?",
                      (username or "", full_name or "", user_id))
            conn.commit()
    conn.close()
    return credits


def set_credits(user_id, credits):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,))
    if c.fetchone() is None:
        c.execute("INSERT INTO users (user_id, credits) VALUES (?,?)", (user_id, credits))
    else:
        c.execute("UPDATE users SET credits=? WHERE user_id=?", (credits, user_id))
    conn.commit()
    conn.close()


def add_credits(user_id, amount):
    current = get_user(user_id)
    set_credits(user_id, current + amount)
    return current + amount


def use_credit(user_id):
    if user_id in OWNER_IDS:
        return True
    credits = get_user(user_id)
    if credits <= 0:
        return False
    set_credits(user_id, credits - 1)
    return True


def is_owner(user_id):
    return user_id in OWNER_IDS


def api_get(endpoint, param_name, value):
    try:
        url = f"{BASE}?={endpoint}&key={KEY}&{param_name}={value}"
        r = requests.get(url, headers=HEADERS, timeout=20)
        if r.status_code == 200:
            return r.json()
        return {"error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"error": str(e)}


def format_result(data):
    if not data:
        return "❌ No data found!"
    if isinstance(data, dict) and data.get("error"):
        return f"❌ {data.get('error')}"
    try:
        # Remove / replace powered by branding
        if isinstance(data, dict):
            for k in list(data.keys()):
                kl = k.lower()
                if "powered" in kl or "ronak" in kl:
                    data[k] = "SHIVNSU//-💀👾🙈"
            # also nested
            def clean(obj):
                if isinstance(obj, dict):
                    for k in list(obj.keys()):
                        if "powered" in k.lower() or "ronak" in k.lower():
                            obj[k] = "SHIVNSU//-💀👾🙈"
                        else:
                            clean(obj[k])
                elif isinstance(obj, list):
                    for i in obj:
                        clean(i)
            clean(data)
        text = json.dumps(data, indent=2, ensure_ascii=False)
        text = text.replace("@Ronak_api", "SHIVNSU//-💀👾🙈")
        text = text.replace("Ronak_api", "SHIVNSU//-💀👾🙈")
        text = text.replace("@ronak_api", "SHIVNSU//-💀👾🙈")
        if len(text) > 3500:
            text = text[:3500] + "\n... (truncated)"
        return f"<pre>{text}</pre>"
    except Exception:
        return str(data)[:3500]


def menu_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("📱 Phone", callback_data="mode:num_info:num"),
            InlineKeyboardButton("🆔 Aadhaar", callback_data="mode:aadhaar2pan:aadhaar2pan"),
        ],
        [
            InlineKeyboardButton("💳 PAN", callback_data="mode:pan2dob_name:pan2dob_name"),
            InlineKeyboardButton("🚗 Vehicle", callback_data="mode:vehicle_full:xr"),
        ],
        [
            InlineKeyboardButton("🚘 Veh→Num", callback_data="mode:vehicle_to_number:xr"),
            InlineKeyboardButton("📟 IMEI", callback_data="mode:imei:imei"),
        ],
        [
            InlineKeyboardButton("📮 Pincode", callback_data="mode:pincode:pincode"),
            InlineKeyboardButton("🏦 IFSC", callback_data="mode:ifse:ifse"),
        ],
        [
            InlineKeyboardButton("👤 Telegram", callback_data="mode:tg:q"),
            InlineKeyboardButton("💰 Credits", callback_data="credits"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    credits = get_user(user.id, user.username or "", user.full_name or "")
    context.user_data["mode"] = None

    if is_owner(user.id):
        credit_line = "👑 <b>Owner — Unlimited credits</b>"
    else:
        credit_line = f"💰 Credits: <b>{credits}</b>"

    text = (
        "💀 <b>OSINT INFO BOT</b>\n\n"
        f"{credit_line}\n\n"
        "Neeche se option choose karo 👇"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=menu_keyboard())


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = query.from_user

    if data == "credits":
        credits = get_user(user.id)
        if is_owner(user.id):
            await query.message.reply_text("👑 Owner — Unlimited credits")
        else:
            await query.message.reply_text(f"💰 Your credits: <b>{credits}</b>", parse_mode="HTML")
        return

    if data == "menu":
        await query.message.reply_text("💀 Menu:", reply_markup=menu_keyboard())
        return

    if data.startswith("mode:"):
        parts = data.split(":")
        endpoint, param = parts[1], parts[2]
        context.user_data["mode"] = (endpoint, param)
        prompts = {
            "num_info": "📱 10 digit number bhejo:",
            "aadhaar2pan": "🆔 12 digit Aadhaar bhejo:",
            "pan2dob_name": "💳 PAN bhejo (e.g. CNKPK7230D):",
            "vehicle_full": "🚗 Vehicle number bhejo (e.g. KL41V3504):",
            "vehicle_to_number": "🚘 Vehicle number bhejo:",
            "imei": "📟 IMEI number bhejo:",
            "pincode": "📮 6 digit pincode bhejo:",
            "ifse": "🏦 IFSC code bhejo:",
            "tg": "👤 Username bhejo (@username):",
        }
        prompt = prompts.get(endpoint, "Value bhejo:")
        await query.message.reply_text(f"🔍 {prompt}")


async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    owner = "✅ Owner (Unlimited)" if is_owner(uid) else "❌ Normal user"
    await update.message.reply_text(
        f"🆔 Your ID: <code>{uid}</code>\n{owner}",
        parse_mode="HTML"
    )


async def credits_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if is_owner(user.id):
        await update.message.reply_text("👑 Owner — Unlimited")
    else:
        await update.message.reply_text(
            f"💰 Credits: <b>{get_user(user.id)}</b>", parse_mode="HTML"
        )


async def addcredit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("❌ Owner only")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /addcredit USER_ID AMOUNT")
        return
    try:
        target, amount = int(context.args[0]), int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Invalid")
        return
    new_bal = add_credits(target, amount)
    await update.message.reply_text(
        f"✅ <code>{target}</code> +{amount}\nBalance: <b>{new_bal}</b>",
        parse_mode="HTML"
    )


async def setcredit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("❌ Owner only")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Usage: /setcredit USER_ID AMOUNT")
        return
    try:
        target, amount = int(context.args[0]), int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Invalid")
        return
    set_credits(target, amount)
    await update.message.reply_text(
        f"✅ <code>{target}</code> set to <b>{amount}</b>", parse_mode="HTML"
    )


async def checkcredit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("❌ Owner only")
        return
    if not context.args:
        await update.message.reply_text("Usage: /checkcredit USER_ID")
        return
    try:
        target = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid")
        return
    await update.message.reply_text(
        f"User <code>{target}</code>\nCredits: <b>{get_user(target)}</b>",
        parse_mode="HTML"
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text.strip()
    mode = context.user_data.get("mode")
    get_user(user.id, user.username or "", user.full_name or "")

    # Direct 10 digit number
    clean = text.replace(" ", "").replace("+91", "").replace("-", "")
    if clean.isdigit() and len(clean) == 10 and not mode:
        if not use_credit(user.id):
            await update.message.reply_text(
                f"❌ Credits khatam! Free limit: {DEFAULT_CREDITS}\nOwner se credits mangwao."
            )
            return
        msg = await update.message.reply_text("⏳ Searching...")
        data = api_get("num_info", "num", clean)
        left = "∞" if is_owner(user.id) else str(get_user(user.id))
        result = format_result(data) + f"\n\n💰 Left: <b>{left}</b>"
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Menu", callback_data="menu")]])
        try:
            await msg.edit_text(result, parse_mode="HTML", reply_markup=kb)
        except TelegramError:
            await msg.edit_text(str(data)[:4000], reply_markup=kb)
        return

    if mode:
        if not use_credit(user.id):
            context.user_data["mode"] = None
            await update.message.reply_text(
                f"❌ Credits khatam! Free limit: {DEFAULT_CREDITS}"
            )
            return
        endpoint, param = mode
        value = text.strip()
        if endpoint == "tg" and not value.startswith("@"):
            value = "@" + value
        if endpoint in ("vehicle_full", "vehicle_to_number"):
            value = value.upper().replace(" ", "")
        if endpoint == "pan2dob_name":
            value = value.upper().replace(" ", "")

        msg = await update.message.reply_text("⏳ Searching...")
        data = api_get(endpoint, param, value)
        context.user_data["mode"] = None
        left = "∞" if is_owner(user.id) else str(get_user(user.id))
        result = format_result(data) + f"\n\n💰 Left: <b>{left}</b>"
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Menu", callback_data="menu")]])
        try:
            await msg.edit_text(result, parse_mode="HTML", reply_markup=kb)
        except TelegramError:
            await msg.edit_text(str(data)[:4000], reply_markup=kb)
        return

    await update.message.reply_text(
        "Option choose karo 👇",
        reply_markup=menu_keyboard()
    )


async def error_handler(update, context):
    logger.error(f"Error: {context.error}\n{traceback.format_exc()}")


def main():
    init_db()
    if not BOT_TOKEN:
        return
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .connect_timeout(30.0)
        .read_timeout(30.0)
        .write_timeout(30.0)
        .pool_timeout(30.0)
        .build()
    )
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("myid", myid))
    app.add_handler(CommandHandler("credits", credits_cmd))
    app.add_handler(CommandHandler("addcredit", addcredit_cmd))
    app.add_handler(CommandHandler("setcredit", setcredit_cmd))
    app.add_handler(CommandHandler("checkcredit", checkcredit_cmd))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_error_handler(error_handler)
    logger.info("💀 OSINT INLINE BOT started")
    app.run_polling(drop_pending_updates=True, allowed_updates=["message", "callback_query"])


if __name__ == "__main__":
    main()
